# Profit_Predictor
This is a machine learning project the predicts the amount of profits depending on the amount of investment 
